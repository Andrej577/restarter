﻿using Serilog;
using System;
using System.IO;
using System.ServiceProcess;
using Newtonsoft.Json;
using System.Collections.Generic;
using static Restarter.Service1;
using System.Threading;
using System.Threading.Tasks;

namespace Restarter
{
    public partial class Service1 : ServiceBase
    {
        private readonly ILogger logger;
        private string logFilePath;
        private string jsonConfigFilePath;

        public class ServiceConfig
        {
            public List<string> Services { get; set; }
        }

        public Service1()
        {
            // Postavljanje putanja za log datoteku i JSON konfiguraciju
            logFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs/log .txt");
            jsonConfigFilePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "services.json");

            // Konfiguracija Serilog-a
            logger = new LoggerConfiguration()
                .WriteTo.File(logFilePath, rollingInterval: RollingInterval.Day)
                .CreateLogger();

            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            Task.Run(() =>
            {
                ServiceConfig serviceConfig = LoadServiceConfig();

                LogMessage("Servis je pokrenut.");

                while (true)
                {
                    DateTime currentTime = DateTime.Now;

                    if (currentTime.TimeOfDay == TimeSpan.Zero || (currentTime.TimeOfDay >= new TimeSpan(06, 00, 0) && currentTime.TimeOfDay <= new TimeSpan(18, 01, 0)))
                    {
                        foreach (string serviceName in serviceConfig.Services)
                        {
                            logger.Information($"Pokušavam restartati servis: '{serviceName}'.");
                            RestartServiceWithLogging(serviceName);
                            logger.Information($"Restartan servis: '{serviceName}'.");

                        }
                    }
                    Thread.Sleep(30000);
                }
            });
        }

        protected override void OnStop()
        {
            LogMessage("Servis je zaustavljen.");
        }

        private void LogMessage(string message)
        {
            logger.Information($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}");
        }


        private void RestartServiceWithLogging(string serviceName)
        {
            try
            {
                // Restart servisa
                RestartService(serviceName);
                logger.Information($"Servis '{serviceName}' je uspešno restartan.");
            }
            catch (Exception ex)
            {
                // Ako dođe do greške, zabeleži je u datoteku
                logger.Error($"Greška prilikom restartanja servisa '{serviceName}': {ex.Message}");
            }
        }

        static void RestartService(string serviceName)
        {
            // Pronalaženje servisa po imenu
            ServiceController serviceController = new ServiceController(serviceName);

            // Ako je servis aktivan, pokušaj ga zaustaviti i ponovo pokrenuti
            if (serviceController.Status == ServiceControllerStatus.Running)
            {
                serviceController.Stop();
                serviceController.WaitForStatus(ServiceControllerStatus.Stopped);
                serviceController.Start();
                serviceController.WaitForStatus(ServiceControllerStatus.Running);
            }
            else
            {
                // Ako servis nije aktivan, pokreni ga
                serviceController.Start();
                serviceController.WaitForStatus(ServiceControllerStatus.Running);
            }
        }

        private ServiceConfig LoadServiceConfig()
        {
            try
            {
                // Čitanje sadržaja JSON datoteke
                string jsonContent = File.ReadAllText(jsonConfigFilePath);

                // Deserijalizacija JSON-a u objekat
                return JsonConvert.DeserializeObject<ServiceConfig>(jsonContent);
            }
            catch (Exception ex)
            {
                // Ako dođe do greške, zabeleži je u log datoteku
                logger.Error($"Greška prilikom učitavanja konfiguracije: {ex.Message}");
                return new ServiceConfig(); // Vraćanje prazne konfiguracije u slučaju greške
            }
        }
    }
}
